# 강의장에 온다면..

## 1. clone

```bash
$ git clone ___
```

* 주의 clone 이후 프로젝트 폴더로 이동해야함!

## 2. 수업 

```bash
$ touch 1223.txt
$ git add .
$ git commit -m '1223'
```

* 집에 가기전에,

```bash
$ git push origin master
```

## 3. 집

* 집에 도착하면, 

```bash
$ git pull origin master
```

* 복습

```bash
$ touch 1223home.txt
$ git add .
$ git commit -m '1223복습'
```

* 자기전에

```bash
$ git push origin master
```

## 4. 강의실

```
## 4.강의실

```



